#ifndef BASIC_MATH_HPP__
#define BASIC_MATH_HPP__

class CBasicMath
{
public:
   int Addition(int x, int y);
   int Substraction(int x,int y);
   int Multiply(int x, int y);
};

#endif
