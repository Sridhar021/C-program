#ifndef PERMISSION_OPERATIONS_H
#define PERMISSION_OPERATIONS_H

#include <string>

void changePermissions(const std::string& path, int permissions);

#endif // PERMISSION_OPERATIONS_H

