#ifndef SEARCH_OPERATIONS_H
#define SEARCH_OPERATIONS_H

#include <string>

void searchFiles(const std::string &path, const std::string &searchTerm);

#endif // SEARCH_OPERATIONS_H
       
